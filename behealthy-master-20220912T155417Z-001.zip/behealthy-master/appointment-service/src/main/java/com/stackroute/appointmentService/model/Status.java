package com.stackroute.appointmentService.model;

public enum Status {
    COMPLETED,
    CANCELLED,
    UPCOMING
}
