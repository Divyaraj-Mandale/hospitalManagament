import 'bootstrap/dist/css/bootstrap.min.css'
//import { Container, Row, Col } from 'react-bootstrap';

import Main from '../Main';
//import SideNavBar from '../../common/Sidebar';
import '../../common/Sidebar.css'


function Profile() {
  return (
  <>
   
    
 
          {/* <MainComponent/> */}
          {/* <Routes>
          <Route path="/profile" element={<Main />} />
        </Routes> */}
            <Main/>

    </>
  );
}
export default Profile;