package com.stackroute.service;

import com.stackroute.model.Email;


public interface EmailService {


    String sendEmail(Email email);


}
