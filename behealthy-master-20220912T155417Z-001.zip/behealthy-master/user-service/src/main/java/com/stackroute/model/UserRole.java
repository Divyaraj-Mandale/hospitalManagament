package com.stackroute.model;

public enum UserRole
{
    DOCTOR,PATIENT

}
