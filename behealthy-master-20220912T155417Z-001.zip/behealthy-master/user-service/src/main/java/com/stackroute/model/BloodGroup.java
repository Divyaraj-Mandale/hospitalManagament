package com.stackroute.model;

public enum BloodGroup
{
    OPositive,
    APositive,
    BPositive,
    ABPositive,
    ONegative,
    ANegative,
    BNegative,
    ABNegative

}
